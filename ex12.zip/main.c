//Ran Lachmy - 207029679
//Eido Peretz - 314652884

#include "httpd.h"

int main(int c, char** v)
{
    serve_forever("8888");
    return 0;
}

